Norma

C4 Model — Nivel 2

Objetivo

Mostrar los grandes bloques.

Estructura
1. Frontend
2. Mobile App
3. API
4. Database
5. Cache
6. Broker
7. Storage