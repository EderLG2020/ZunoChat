Norma

C4 Model — Nivel 3

Objetivo

Explicar módulos internos.

Estructura
1. Auth
2. Users
3. Chat
4. Notifications
5. Payments
6. Search